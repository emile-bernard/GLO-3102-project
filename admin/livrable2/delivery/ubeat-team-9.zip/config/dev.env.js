var merge = require('webpack-merge')

module.exports = {
  NODE_ENV: '"development"'
}
