<template>
  <div>
    <h1>Settings</h1>
    <div>GLO-3102 Settings page</div>
  </div>
</template>

<style>
</style>

