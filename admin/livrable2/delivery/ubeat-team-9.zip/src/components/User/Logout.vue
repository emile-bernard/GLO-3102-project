<template>
  <div>
    <h1>Logout</h1>
    <div>GLO-3102 Logout page</div>
  </div>
</template>

<style>
</style>
