<template>
  <div>
    <h1>Playlist</h1>
    <div>GLO-3102 Playlist page</div>
  </div>
</template>

<style>
</style>
