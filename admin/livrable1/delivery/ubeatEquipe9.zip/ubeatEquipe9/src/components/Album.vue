<template>
  <section class="section">
    <p>
      <router-link to="/"><span>UBeat</span></router-link>
      <span> > </span>
      <router-link to="/album"><span>Album</span></router-link>
      <span> > </span>
      <router-link to="/album"><span>Die Antword</span></router-link>
    </p>
    <br/>
    <div class="container">
      <h1 class="title is-size-2">Die Antword</h1>
      <section id="album-hero-parralax-bg" class="hero hero-parralax-bg">
        <div class="hero-body">
          <album-cover
            v-bind:refLink="'https://itunes.apple.com/gb/album/ten%24ion/732912112'"
            v-bind:imgSrc="'https://bit.ly/2P2Lo1n'"
            v-bind:playRef="'https://www.youtube.com/watch?v=GmwhBSh2rOs'"
          ></album-cover>
          <album-information></album-information>
        </div>
      </section>
      <!--Todo: timeline into another component-->
    </div>
  </section>
</template>

<style>
  .hero-parralax-bg {
    overflow: auto;
    position: relative;
  }

  #album-hero-parralax-bg:before {
    content: '';
    position: absolute;
    display: block;
    background: url('https://bit.ly/2P2Lo1n') no-repeat center center fixed;
    background-size: cover;
    -webkit-filter: blur(50px);
    -moz-filter: blur(50px);
    -o-filter: blur(50px);
    -ms-filter: blur(50px);
    filter: blur(50px);
    width: 100%;
    height: 100%;
  }

  .hero-parralax-bg * {
    z-index: 10;
  }

  .hero-body {
    background-color: rgba(0, 0, 0, 0.1);
    text-align: center;
    display: flex;
    flex-wrap: wrap;
    justify-content: space-around;
    align-content: flex-start;
    align-items: center;
    flex-direction: row;
    column-gap: 0;
  }
</style>

<script>
  import AlbumCover from '@/components/AlbumCover';
  import AlbumInformation from '@/components/AlbumInformation';

  export default {
    components: {
      'album-cover': AlbumCover,
      'album-information': AlbumInformation
    }
  };
</script>
