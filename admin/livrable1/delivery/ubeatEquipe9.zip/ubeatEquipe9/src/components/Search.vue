<template>
  <div>
    <h1>Search</h1>
    <div>GLO-3102 Search page</div>
  </div>
</template>

<style>
</style>

